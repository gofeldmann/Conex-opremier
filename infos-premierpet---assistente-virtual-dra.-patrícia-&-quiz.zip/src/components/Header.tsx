import React from 'react';
import { PetProfile } from '../types';
import { Sparkles } from 'lucide-react';
import { DEFAULT_PATRICIA_AVATAR, FALLBACK_PATRICIA_AVATAR } from '../utils/defaultImages';

interface HeaderProps {
  petProfile?: PetProfile;
  onOpenPetModal?: () => void;
  avatarUrl?: string;
}

export const Header: React.FC<HeaderProps> = ({
  avatarUrl = DEFAULT_PATRICIA_AVATAR,
}) => {
  return (
    <>
      <header className="w-full max-w-3xl mx-auto px-4 pt-4">
        {/* Top Header Card matching Screenshot 1 */}
        <div className="bg-[#2532f5] text-white p-5 sm:p-6 rounded-[28px] sm:rounded-[32px] shadow-md flex items-center justify-between gap-4 relative overflow-hidden">
          <div className="flex items-center gap-3.5 relative z-10">
            <div className="relative shrink-0">
              <img
                src={avatarUrl || DEFAULT_PATRICIA_AVATAR}
                alt="Dra. Patrícia"
                referrerPolicy="no-referrer"
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-full object-cover border-2 border-white/90 shadow-sm bg-white/20"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = FALLBACK_PATRICIA_AVATAR;
                }}
              />
              <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-sky-400 border-2 border-[#2532f5] rounded-full"></span>
            </div>

            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-tight">
                Conexão PremieR
              </h1>
              <p className="text-xs sm:text-sm text-blue-100/90 font-medium mt-0.5">
                Dúvidas sobre a alimentação do seu pet
              </p>
            </div>
          </div>
        </div>
      </header>
    </>
  );
};

